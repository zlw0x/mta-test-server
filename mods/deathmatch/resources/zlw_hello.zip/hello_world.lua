function Hello()
	outputChatBox("Hello world!", source)
end
addEventHandler("onPlayerJoin", getRootElement(), Hello)